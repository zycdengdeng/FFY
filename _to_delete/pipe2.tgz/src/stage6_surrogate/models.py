"""两级保真度的冲击模型(多保真代理实验的地基)。

LF(低保真): 1-DOF 线性弹簧-阻尼(现有 Stage4 模型),解析、微秒级。
HF(高保真): 2-DOF 平面连杆落震——接触点铰接,广义坐标 q1(下段绕触点转角)、
             q2(踝弯角),髋部集中质量,拉格朗日动力学 + 关节扭簧/阻尼,RK4。
             非线性:大转角、位形相关惯量、几何刚化——LF 完全没有的物理。

共同输入 x=(L1_mm, r2, r3);共同场景(m, v0, 关节 k/c, 初始姿态)固定。
输出:peak_a(m/s²), stroke(m)。
"""
from __future__ import annotations
import numpy as np

SCEN = dict(m=200.0, v0=3.0, g=9.81,
            k1=4.5e3, k2=4.5e3,      # 关节扭簧 N·m/rad
            c1=4.0e2, c2=4.0e2,      # 线性阻尼(LF 用;HF 只保留小线性项)
            cq=90.0,                 # HF:液压式平方阻尼 N·m·(s/rad)²
            dq_stop=np.radians(55.), # HF:膝弯行程限位(超过后渐进撞块)
            k_stop=1.5e4,            # 撞块刚度
            q1_0=np.radians(50.0),   # 下段初始仰角(触地 ψ≈50°)
            thetaA=np.radians(120.0),
            thetaK=np.radians(90.0))

BOUNDS = dict(L1=(250.0, 490.0), r2=(1.3, 2.5), r3=(0.9, 2.0))

# —— 真实水鸟尺度(2026-08 收缩决定:固定姿态,质量/速度/腿长按真鸟) ——
SCEN_BIRD = dict(m=5.0, v0=1.2, g=9.81,
                 k1=35.0, k2=35.0,        # 关节扭簧 N·m/rad(鸟尺度)
                 c1=1.2, c2=1.2,          # 关节阻尼 N·m·s/rad
                 cq=0.0, dq_stop=np.radians(55.0), k_stop=300.0,
                 q1_0=np.radians(50.0), thetaA=np.radians(120.0), thetaK=np.radians(90.0))
# 设计空间边界 v2(2026-08 数据重置):全部来自公开实测,不再依赖蓝本/自标
#  L1 : AVONET 1-12kg 水鸟 101 种跗跖实测 33-121mm(与 Watanabe 骨架 TMT 25-120 互证)
#  r2 : Watanabe 2017 (Auk 134:672) 附录表10,91 种会飞雁鸭科 TIB/TMT 实测全距 1.49-2.09
#  r3 : 同上,FEM/TMT 实测全距 0.84-1.28(旧上界 1.9 探索的是非生物区)
BOUNDS_BIRD = dict(L1=(33.0, 121.0), r2=(1.49, 2.09), r3=(0.84, 1.28))
LO_BIRD = [BOUNDS_BIRD[k][0] for k in ("L1", "r2", "r3")]
HI_BIRD = [BOUNDS_BIRD[k][1] for k in ("L1", "r2", "r3")]

# —— E4 扩维:刚度/阻尼解耦(7 维设计空间)——
# x7 = (L1, r2, r3, κ_踝, κ_膝, κ_髋, ζ阻尼比)
# 刚度仍按量纲规则 k=κ·m·g·L_leg,但三关节 κ 独立可选;范围覆盖旧默认 (4,4,16,0.03)
# 并向两侧展开——"生物没有的自由度",E4 的核心问题所在。
BOUNDS_BIRD7 = dict(**BOUNDS_BIRD, kap_a=(1.5, 8.0), kap_k=(1.5, 8.0),
                    kap_h=(6.0, 32.0), zeta=(0.01, 0.10))
_K7 = ("L1", "r2", "r3", "kap_a", "kap_k", "kap_h", "zeta")
LO_BIRD7 = [BOUNDS_BIRD7[k][0] for k in _K7]
HI_BIRD7 = [BOUNDS_BIRD7[k][1] for k in _K7]

# —— E11 仿生先验消融:只改几何盒子(生物数据唯一进入设计空间之处),
#    刚度/阻尼范围三臂完全一致(它们来自量纲论证,与鸟类数据无关)。
#    bio   : AVONET 101 种 + Watanabe 91 种实测(体积基准 88×0.60×0.44)
#    wide  : 工程朴素宽界,无生物知识(体积 ≈ 94× bio,且包含 bio 盒)
#    shift : 与 bio 等体积但比例非生物(长胫短股)——把"窄"与"位置对"分开
BOUNDS_WIDE7 = dict(BOUNDS_BIRD7, L1=(20.0, 250.0), r2=(0.50, 4.00), r3=(0.30, 3.00))
BOUNDS_SHIFT7 = dict(BOUNDS_BIRD7, L1=(33.0, 121.0), r2=(2.20, 2.80), r3=(0.30, 0.74))
LO_WIDE7 = [BOUNDS_WIDE7[k][0] for k in _K7]
HI_WIDE7 = [BOUNDS_WIDE7[k][1] for k in _K7]
LO_SHIFT7 = [BOUNDS_SHIFT7[k][0] for k in _K7]
HI_SHIFT7 = [BOUNDS_SHIFT7[k][1] for k in _K7]
BOXES7 = {"bio": (LO_BIRD7, HI_BIRD7), "wide": (LO_WIDE7, HI_WIDE7),
          "shift": (LO_SHIFT7, HI_SHIFT7)}


def bird_size_x(scen, x):
    """通用尺寸化:len(x)==3 走 bird_size 默认规则;len(x)==7 刚度/阻尼解耦。"""
    x = list(x)
    if len(x) == 3:
        return bird_size(scen, x)
    L1, r2, r3, ka, kk, kh, z = x
    Lleg = (L1 / 1000.0) * (1.0 + r2 + r3)
    mgL = scen["m"] * scen["g"] * Lleg
    s2 = dict(scen)
    s2["k_ankle"] = ka * mgL; s2["k_knee"] = kk * mgL; s2["k_hip"] = kh * mgL
    s2["k1"] = s2["k_ankle"]; s2["k2"] = s2["k_knee"]
    s2["c_ankle"] = z * s2["k_ankle"]; s2["c_knee"] = z * s2["k_knee"]
    s2["c1"] = s2["c_ankle"]; s2["c2"] = s2["c_knee"]
    s2["c_hip"] = (z / 0.03) * 0.2 * s2["k_hip"]     # 保持旧默认比例关系
    s2["kc"] = 4000.0 * scen["m"] * scen["g"]
    s2["cc"] = 0.01 * s2["kc"]
    return s2

def bird_size(scen, x):
    """尺寸化规则:关节刚度按载荷与腿长配簧(k=κ·m·g·L_leg, κ=3;c=0.03k)。
    物理含义:每套设计按其载荷选簧,如真实工程;避免一套弹簧同时伺候1kg与12kg。"""
    L1, r2, r3 = x
    Lleg = (L1 / 1000.0) * (1.0 + r2 + r3)
    k = scen.get("kappa", 4.0) * scen["m"] * scen["g"] * Lleg
    s2 = dict(scen)
    s2["k1"] = s2["k2"] = k; s2["c1"] = s2["c2"] = 0.03 * k
    s2["k_ankle"] = s2["k_knee"] = k; s2["c_ankle"] = s2["c_knee"] = 0.03 * k
    s2["k_hip"] = 4.0 * k; s2["c_hip"] = 0.2 * k
    s2["kc"] = 4000.0 * scen["m"] * scen["g"]      # 接触刚度随载荷配(防重鸟压穿)
    s2["cc"] = 0.01 * s2["kc"]
    return s2
# 工况(5维附加):v0∈[0.5,2.0] m/s(水鸟着水下沉速度,文献量级),m∈[1,12] kg(鸭→天鹅)


def _geom(x, s=SCEN):
    """x=(L1_mm,r2,r3) → 等效两连杆长度 l1, l2(米)。
    l2 = 踝→髋 虚拟杆:L2、L3 夹 thetaK 的对边(余弦定理)。"""
    L1, r2, r3 = x
    l1 = L1 / 1000.0
    L2, L3 = r2 * l1, r3 * l1
    l2 = np.sqrt(L2 ** 2 + L3 ** 2 - 2 * L2 * L3 * np.cos(s["thetaK"]))
    return l1, l2


def lf_eval(x, s=SCEN, dt=5e-4, T=1.2):
    """LF:力臂折算串联刚度的 1-DOF 线性落震(同 Stage4 思路)。"""
    l1, l2 = _geom(x, s)
    q1, q2 = s["q1_0"], np.pi - s["thetaA"]          # 初始位形
    # 触点→踝、触点→髋 的水平力臂
    ankle = np.array([l1 * np.cos(q1), l1 * np.sin(q1)])
    hip = ankle + l2 * np.array([np.cos(q1 + q2), np.sin(q1 + q2)])
    Ja, Jh = max(abs(ankle[0]), 1e-3), max(abs(hip[0]), 1e-3)
    K = 1.0 / (Ja ** 2 / s["k1"] + Jh ** 2 / s["k2"])
    C = 1.0 / (Ja ** 2 / s["c1"] + Jh ** 2 / s["c2"])
    m, g, v = s["m"], s["g"], s["v0"]
    d, vv = 0.0, v
    peak, dmax = 0.0, 0.0
    for _ in range(int(T / dt)):
        a = g - (C * vv + K * d) / m
        peak = max(peak, abs(a)); 
        vv += a * dt; d += vv * dt
        dmax = max(dmax, d)
        if vv < 0: break
    return dict(peak_a=peak, stroke=dmax)


def hf_eval(x, s=SCEN, dt=2e-4, T=1.5):
    """HF:2-DOF 平面连杆(触点铰接 + 髋部点质量)拉格朗日动力学。
    M(q) qdd + m J^T Jd qd = J^T F_g + tau_spring;小关节惯量正则化防奇异。"""
    l1, l2 = _geom(x, s)
    m, g = s["m"], s["g"]
    q = np.array([s["q1_0"], np.pi - s["thetaA"]])   # q2: 踝处外角(0=伸直)
    q0 = q.copy()
    # 初速:髋竖直 -v0 → 关节速率(最小范数逆解)
    def jac(q):
        s1, c1 = np.sin(q[0]), np.cos(q[0])
        s12, c12 = np.sin(q[0] + q[1]), np.cos(q[0] + q[1])
        return np.array([[-l1 * s1 - l2 * s12, -l2 * s12],
                         [ l1 * c1 + l2 * c12,  l2 * c12]])
    J = jac(q)
    qd = np.linalg.lstsq(J, np.array([0.0, -s["v0"]]), rcond=None)[0]
    Ireg = np.diag([0.06 * m * l1 ** 2, 0.06 * m * l2 ** 2])   # 段惯量近似(正则)
    kvec = np.array([s["k1"], s["k2"]])
    clin = np.array([s["c1"], s["c2"]]) * 0.25          # HF 线性阻尼只留小项
    cq, dstop, kstop = s["cq"], s["dq_stop"], s["k_stop"]

    def qdd_f(q, qd):
        s1, c1 = np.sin(q[0]), np.cos(q[0])
        s12, c12 = np.sin(q[0] + q[1]), np.cos(q[0] + q[1])
        J = np.array([[-l1 * s1 - l2 * s12, -l2 * s12],
                      [ l1 * c1 + l2 * c12,  l2 * c12]])
        # dJ/dt
        w1, w12 = qd[0], qd[0] + qd[1]
        Jd = np.array([[-l1 * c1 * w1 - l2 * c12 * w12, -l2 * c12 * w12],
                       [-l1 * s1 * w1 - l2 * s12 * w12, -l2 * s12 * w12]])
        M = m * J.T @ J + Ireg
        tau = -kvec * (q - q0) - clin * qd - cq * qd * np.abs(qd)   # 液压平方阻尼
        over = np.abs(q - q0) - dstop                                # 行程限位撞块
        tau -= np.where(over > 0, kstop * over * np.sign(q - q0), 0.0)
        rhs = J.T @ np.array([0.0, -m * g]) - m * J.T @ (Jd @ qd) + tau
        return np.linalg.solve(M, rhs), J, Jd

    hip_y = lambda q: l1 * np.sin(q[0]) + l2 * np.sin(q[0] + q[1])
    y0 = hip_y(q)
    peak, dmax = 0.0, 0.0
    n = int(T / dt)
    for i in range(n):
        qdd, J, Jd = qdd_f(q, qd)
        acc_y = (Jd @ qd + J @ qdd)[1]                 # 髋竖直加速度
        peak = max(peak, abs(acc_y))
        # RK4
        k1a, _, _ = qdd_f(q, qd)
        k2a, _, _ = qdd_f(q + 0.5 * dt * qd, qd + 0.5 * dt * k1a)
        k3a, _, _ = qdd_f(q + 0.5 * dt * (qd + 0.5 * dt * k1a), qd + 0.5 * dt * k2a)
        k4a, _, _ = qdd_f(q + dt * (qd + 0.5 * dt * k2a), qd + dt * k3a)
        qd = qd + dt * (k1a + 2 * k2a + 2 * k3a + k4a) / 6.0
        q = q + dt * qd
        drop = y0 - hip_y(q); dmax = max(dmax, drop)
        vy = (jac(q) @ qd)[1]
        if vy > 0 and i > 20: break                    # 髋开始回升 → 压缩相结束
        if hip_y(q) < 0.05 * (l1 + l2) or not np.all(np.isfinite(q)):
            return dict(peak_a=np.nan, stroke=np.nan)  # 塌陷/发散
    return dict(peak_a=peak, stroke=dmax)


def lhs(n, seed=0):
    rng = np.random.default_rng(seed)
    dims = [BOUNDS["L1"], BOUNDS["r2"], BOUNDS["r3"]]
    out = np.empty((n, 3))
    for j, (a, b) in enumerate(dims):
        edges = a + (b - a) * (np.arange(n) + rng.random(n)) / n
        out[:, j] = rng.permutation(edges)
    return out
